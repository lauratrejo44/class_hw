my_file_name = "dna.txt"
my_contents = my_file_name.read()

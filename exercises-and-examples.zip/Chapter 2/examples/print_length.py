dna_length = len("AGTC")
print(dna_length)

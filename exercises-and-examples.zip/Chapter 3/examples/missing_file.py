my_file = open("nonexistent.txt")

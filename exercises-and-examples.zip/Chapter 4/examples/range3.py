for number in range(2, 14, 4):
    print(number)

count = 0
while count<10:
    print(count)
    count = count + 1


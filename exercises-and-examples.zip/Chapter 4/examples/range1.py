for number in range(6):
    print(number)

my_file = open("out.txt", "w")
my_file.write("Hello world")
# remember to close the file
my_file.close()

my_file = open("out.txt", "w")
my_file.write("Hello world")

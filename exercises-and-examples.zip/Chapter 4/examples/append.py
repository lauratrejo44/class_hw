apes = ["Homo sapiens", "Pan troglodytes", "Gorilla gorilla"]
print(apes)
apes.append("Pan paniscus")
print(apes)

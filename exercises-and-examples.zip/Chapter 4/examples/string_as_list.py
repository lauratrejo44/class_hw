name = "python"
for character in name:
    print("one character is " + character)

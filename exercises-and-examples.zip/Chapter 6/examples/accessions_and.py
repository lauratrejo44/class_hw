accs = ['ab56', 'bh84', 'hv76', 'ay93', 'ap97', 'bd72']
for accession in accs:
	if accession.startswith('a') and accession.endswith('3'):
		print(accession)
